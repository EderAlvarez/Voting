<?php ob_start();
session_start();

$db_host = 'localhost';
$db_user = 'your-mysql-username'; // your mysql username
$db_pass = 'your-mysql-password'; // your mysql password
$db_name = 'your-mysql-db-name'; // your mysql db name

$db = new mysqli($db_host,$db_user,$db_pass,$db_name);
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

date_default_timezone_set('UTC'); // Don't change timezone :) Please!!!
?>